<?php
// Generado por Vite. No editar a mano.
return array(
	'dependencies' => array(),
	'version' => '7f3e04b05d65',
	'pages' => array('dashboard', 'content', 'strings', 'history', 'settings'),
);
