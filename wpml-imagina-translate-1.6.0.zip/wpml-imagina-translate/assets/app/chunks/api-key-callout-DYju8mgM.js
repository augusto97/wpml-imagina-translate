import{c as n,e as i,j as e,C as t,B as r,x as s}from"./callout-2F8u2MTE.js";import{K as o}from"./textarea-Bds63b0I.js";/**
 * @license lucide-react v0.456.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const u=n("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);/**
 * @license lucide-react v0.456.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=n("Search",[["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}],["path",{d:"m21 21-4.3-4.3",key:"1qie3q"}]]);function p(){const a=i();return a.features.apiKey?null:e.jsx(t,{kind:"warning",title:"Falta la API key del proveedor de IA",action:a.canManage?e.jsxs(r,{size:"sm",variant:"outline",onClick:()=>{window.location.href=s("settings",{tab:"provider"})},children:[e.jsx(o,{className:"wit-h-4 wit-w-4"}),"Configurar"]}):void 0,children:a.canManage?"Sin ella no se puede traducir desde aquí. Si traduces con Claude por MCP, no la necesitas.":"Pide a un administrador que la configure en IA Translate → Ajustes."})}export{p as A,u as P,d as S};
