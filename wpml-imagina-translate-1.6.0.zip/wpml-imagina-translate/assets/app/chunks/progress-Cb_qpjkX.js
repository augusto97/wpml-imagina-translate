import{c as s,j as e,a as t}from"./callout-2F8u2MTE.js";/**
 * @license lucide-react v0.456.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=s("Square",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",key:"afitv7"}]]);function o({segments:i,total:l,className:r}){return e.jsx("div",{className:t("wit-flex wit-h-2 wit-w-full wit-overflow-hidden wit-rounded-full wit-bg-slate-100",r),role:"img","aria-label":i.map(a=>`${a.label}: ${a.value}`).join(", "),children:l>0&&i.map(a=>a.value>0?e.jsx("div",{className:t("wit-h-full wit-transition-all",a.className),style:{width:`${a.value/l*100}%`}},a.label):null)})}function u({value:i,className:l}){return e.jsx("div",{className:t("wit-h-2 wit-w-full wit-overflow-hidden wit-rounded-full wit-bg-slate-100",l),role:"progressbar","aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":Math.round(i),children:e.jsx("div",{className:"wit-h-full wit-bg-primary wit-transition-all",style:{width:`${Math.min(100,Math.max(0,i))}%`}})})}export{u as P,o as S,w as a};
