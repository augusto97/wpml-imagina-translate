import{c as i,j as e,m as s}from"./callout-2F8u2MTE.js";import{B as a}from"./bot-DJchajdp.js";/**
 * @license lucide-react v0.456.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const n=i("MonitorSmartphone",[["path",{d:"M18 8V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h8",key:"10dyio"}],["path",{d:"M10 19v-3.96 3.15",key:"1irgej"}],["path",{d:"M7 19h5",key:"qswx4l"}],["rect",{width:"6",height:"10",x:"16",y:"12",rx:"2",key:"1egngj"}]]),r={openai:"OpenAI",claude:"Claude API",gemini:"Gemini"};function w({via:t}){return t==="mcp"?e.jsxs("span",{className:"wit-inline-flex wit-items-center wit-gap-1 wit-text-violet-700",children:[e.jsx(s,{className:"wit-h-3.5 wit-w-3.5"}),"Claude"]}):t==="panel"?e.jsxs("span",{className:"wit-inline-flex wit-items-center wit-gap-1 wit-text-muted-foreground",children:[e.jsx(n,{className:"wit-h-3.5 wit-w-3.5"}),"Panel"]}):e.jsxs("span",{className:"wit-inline-flex wit-items-center wit-gap-1 wit-text-muted-foreground",children:[e.jsx(a,{className:"wit-h-3.5 wit-w-3.5"}),r[t]??t]})}export{w as V};
