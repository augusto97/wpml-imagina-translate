<?php

use WPML\FP\Obj;

class WPML_Package_Helper {
	const PREFIX_BATCH_STRING = 'batch-string-';

	private $default_language;
	private $last_registered_string_id;
	protected $registered_strings;
	private $package_cleanup;
	private $package_factory;

	private $cache_group;

	function __construct() {
		$this->registered_strings = array();
		$this->cache_group        = 'string_package';
		$this->package_cleanup    = new WPML_ST_Package_Cleanup();
		$this->package_factory    = new WPML_ST_Package_Factory();
	}

	public function set_package_factory( WPML_ST_Package_Factory $factory ) {
		$this->package_factory = $factory;
	}

	protected function delete_package( $package_id ) {

		$this->delete_package_strings( $package_id );

		$tm = new WPML_Package_TM( $this->package_factory->create( $package_id ) );
		$tm->delete_translation_jobs();
		$tm->delete_translations();

		global $wpdb;
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->prefix}icl_string_packages WHERE id = %d",
				$package_id
			)
		);

		$package = $tm->get_package();
		$domain  = $package->kind_slug . '-' . $package->name;
		$domain = str_replace( '/', '-', $domain );

		do_action( 'wpml_st_refresh_domain', $domain );
	}

	protected function get_strings_ids_from_package_id( $package_id ) {
		global $wpdb;
		$string_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT id FROM {$wpdb->prefix}icl_strings WHERE string_package_id = %d",
				$package_id
			)
		);

		return $string_ids;
	}

	protected function delete_package_strings( $package_id ) {
		$strings = $this->get_strings_ids_from_package_id( $package_id );

		foreach ( $strings as $string_id ) {
			do_action( 'wpml_st_delete_all_string_data', $string_id );
		}
	}

	protected function loaded() {
		$this->default_language = icl_get_default_language();
	}

	final function register_string_action( $string_value, $string_name, $package, $string_title, $string_type ) {
		$this->register_string_for_translation( $string_value, $string_name, $package, $string_title, $string_type );

		return $this->last_registered_string_id;
	}

	function string_id_from_package_filter( $default, $package, $string_name, $string_value ) {
		$string_id = $this->get_string_id_from_package( $package, $string_name, $string_value );
		if ( ! $string_id ) {
			return $default;
		}

		return $string_id;
	}

	function string_title_from_id_filter( $default, $string_id ) {
		global $wpdb;

		$string_title = false;

		if ( $string_id ) {
			$string_title = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT title FROM {$wpdb->prefix}icl_strings WHERE id = %d",
					$string_id
				)
			);
		}

		if ( ! $string_title ) {
			$string_title = $default;
		}

		return $string_title;
	}

	final public function register_string_for_translation( $string_value, $string_name, $package, $string_title, $string_type ) {
		$package    = $this->package_factory->create( $package );
		$package_id = $package->ID;
		if ( ! $package_id ) {

			if ( $package->has_kind_and_name() ) {
				$package_id = self::create_new_package( $package );
				$package    = $this->package_factory->create( $package );
			}
		}
		if ( $package_id ) {
			$this->maybe_update_package( $package );
			$tm = new WPML_Package_TM( $package );
			$tm->validate_translations();

			$this->init_package_registered_strings( $package_id );

			$string_name = $package->sanitize_string_name( $string_name );

			$this->set_package_registered_strings( $package_id, $string_type, $string_title, $string_name, $string_value );
			$this->last_registered_string_id = $this->register_string_with_wpml( $package, $string_name, $string_title, $string_type, $string_value );
			$this->package_cleanup->record_register_string( $package, $this->last_registered_string_id );
		}

		do_action( 'wpml_st_string_registered' );

		do_action( 'wpml_st_package_string_registered', $package );

		return $string_value;
	}

	final function get_string_context_from_package( $package ) {
		$package = $this->package_factory->create( $package );

		return $package->get_string_context_from_package();
	}

	final function register_string_with_wpml( $package, $string_name, $string_title, $string_type, $string_value ) {
		global $wpdb;

		$string_id = $this->get_string_id_from_package( $package, $string_name, $string_value );

		if ( $string_id ) {
			$package_storage = new WPML_ST_Package_Storage( $package->ID, $wpdb );
			$did_update      = $package_storage->update( $string_title, $string_type, $string_value, $string_id );

			if ( $did_update ) {
				$this->flush_cache();
				$package->flush_cache();

				do_action( 'wpml_st_string_updated' );
			}
		}

		return $string_id;
	}

	final function translate_string( $string_value, $string_name, $package ) {
		$result = $string_value;

		if ( is_string( $string_value ) ) {
			$package = is_scalar( $package ) ? [ 'ID' => $package ] : Obj::assoc( 'translate_only', true, $package );
			$package = $this->package_factory->create( $package );

			if ( $package ) {
				$sanitized_string_name = $package->sanitize_string_name( $string_name );

				$result = $package->translate_string( $string_value, $sanitized_string_name );
			}
		}

		return $result;
	}

	final function get_translated_strings( $strings, $package ) {
		$package = $this->package_factory->create( $package );

		return $package->get_translated_strings( $strings );
	}

	final function set_translated_strings( $translations, $package ) {
		$package = $this->package_factory->create( $package );
		$package->set_translated_strings( $translations );
	}

	final function get_translatable_types( $types ) {
		global $wpdb;

		$package_kinds = $wpdb->get_results( "SELECT kind, kind_slug FROM {$wpdb->prefix}icl_string_packages WHERE id>0" );

		foreach ( $package_kinds as $package_data ) {
			$package_kind_slug = $package_data->kind_slug;
			$package_kind      = $package_data->kind;
			$kinds_added       = array_keys( $types );
			if ( ! in_array( $package_kind_slug, $kinds_added ) ) {
				$translatable_type                        = new stdClass();
				$translatable_type->name                  = $package_kind_slug;
				$translatable_type->label                 = $package_kind;
				$translatable_type->prefix                = 'package';
				$translatable_type->labels                = new stdClass();
				$translatable_type->labels->singular_name = $package_kind;
				$translatable_type->labels->name          = $package_kind;
				$translatable_type->external_type         = 1;
				$types[ $package_kind_slug ]              = $translatable_type;
			}
		}

		return $types;
	}

	final public function get_translatable_item( $item, $package, $type = 'package' ) {
		if ( $type === 'package' || explode( '_', is_null( $type ) ? '' : $type )[0] === 'package' ) {
			$tm = new WPML_Package_TM( $item );

			return $tm->get_translatable_item( $package );
		}

		return $item;
	}

	final function get_post_title( $title, $package_id ) {
		$package = $this->package_factory->create( $package_id );
		if ( $package ) {
			$title = $package->kind . ' - ' . $package->title;
		}

		return $title;
	}

	final function get_editor_string_name( $name, $package ) {
		$package    = $this->package_factory->create( $package );
		$package_id = $package->ID;
		$title      = $this->get_editor_string_element( $name, $package_id, 'title' );
		if ( $title && $title != '' ) {
			$name = $title;
		} elseif (
			\WPML\FP\Str::includes( self::PREFIX_BATCH_STRING, $name )
			&& ( $string = $this->get_st_string_by_batch_name( $name ) )
		) {
			$name = $this->empty_if_md5( $string->get_name() )
				?: ( $string->get_gettext_context() ?: ( $string->get_context() ?: $name ) );
		}

		return $name;
	}

	private function empty_if_md5( $str ) {
		return preg_replace( '#^((.+)( - ))?([a-z0-9]{32})$#', '$2', $str );
	}

	private function get_st_string_by_batch_name( $batch_string_name ) {
		$string_id = (int) \WPML\FP\Str::replace( self::PREFIX_BATCH_STRING, '', $batch_string_name );
		if ( $string_id ) {
			$string_factory = WPML\Container\make( WPML_ST_String_Factory::class );

			return $string_factory->find_by_id( $string_id );
		}

		return null;
	}

	final function get_editor_string_style( $style, $field_type, $package ) {
		$package       = $this->package_factory->create( $package );
		$package_id    = $package->ID;
		$element_style = $this->get_editor_string_element( $field_type, $package_id, 'type' );
		if ( $element_style ) {
			$style = 0;
			if ( defined( $element_style ) ) {
				$style = constant( $element_style );
			}
		}

		return $style;
	}

	final public function get_element_id_from_package_filter( $default, $package_id ) {
		global $wpdb;
		$element_id = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT name FROM {$wpdb->prefix}icl_string_packages WHERE ID = %d",
				$package_id
			)
		);
		if ( ! $element_id ) {
			$element_id = $default;
		}

		return $element_id;
	}

	final public function get_package_type( $type, $post_id ) {
		$package = $this->package_factory->create( $post_id );
		if ( $package ) {
			return $this->get_package_context( $package );
		} else {
			return $type;
		}
	}

	final public function get_package_type_prefix( $type, $post_id ) {
		if ( $type == 'package' ) {
			$package = $this->package_factory->create( $post_id );
			if ( $package ) {
				$type = $package->get_string_context_from_package();
			}
		}

		return $type;
	}

	final public function get_language_for_element( $language_for_element, $current_document ) {
		if ( $this->is_a_package( $current_document ) ) {
			global $sitepress;
			$language_for_element = $sitepress->get_language_for_element( $current_document->ID, $current_document->get_translation_element_type() );
		}

		return $language_for_element;
	}

	final protected function get_package_context( $package ) {
		$package = $this->package_factory->create( $package );

		return $package->kind_slug . '-' . $package->name;
	}

	final function delete_packages_ajax() {
		if ( ! $this->verify_ajax_call( 'wpml_package_nonce' ) ) {
			die( 'verification failed' );
		}
		$packages_ids = $_POST['packages'];

		$deleted = $this->delete_packages( $packages_ids );

		wp_send_json_success( array( 'deleted' => $deleted ) );
	}

	final function delete_package_action( $name, $kind ) {
		$package_data['name'] = $name;
		$package_data['kind'] = $kind;

		$package = $this->package_factory->create( $package_data );
		if ( $package && $package->ID && $this->is_a_package( $package ) ) {
			$this->delete_package( $package->ID );
			$this->flush_cache();
		}
	}

	final public function remove_post_packages( $post_id ) {
		$packages = $this->get_post_string_packages( array(), $post_id );

		foreach ( $packages as $package ) {
			$this->delete_package( $package->ID );
		}
	}

	final protected function delete_packages( $packages_ids ) {
		global $wpdb;

		$packages_ids = array_unique(
			array_filter(
				array_map( 'intval', (array) $packages_ids ),
				function ( $package_id ) {
					return $package_id > 0;
				}
			)
		);

		if ( $packages_ids ) {
			$packages_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->prefix}icl_string_packages WHERE ID IN ("
					. implode( ', ', array_fill( 0, count( $packages_ids ), '%d' ) ) . ')',
					$packages_ids
				)
			);
		}

		$deleted = 0;

		foreach ( $packages_ids as $package_id ) {
			$this->delete_package( $package_id );

			$deleted++;
		}
		if ( $deleted ) {
			$this->flush_cache();
		}

		return $deleted;
	}

	final function change_package_lang_ajax() {
		global $wpdb, $sitepress;

		if ( ! $this->verify_ajax_call( 'wpml_package_nonce' ) ) {
			die( 'verification failed' );
		}

		$package_id = isset( $_POST['package_id'] ) ? wp_unslash( $_POST['package_id'] ) : '';
		if ( ! is_scalar( $package_id ) || ( '' !== (string) $package_id && ! ctype_digit( (string) $package_id ) ) ) {
			wp_send_json_error( null, 400 );

			return;
		}

		$package = $this->package_factory->create( absint( $package_id ) );
		$package->set_strings_language( $_POST['package_lang'] );

		$package_job = new WPML_Package_TM( $package );
		$package_job->set_language_details( $_POST['package_lang'] );

		$args = json_decode( base64_decode( $_POST['args'] ) );
		$args = array_map( 'sanitize_text_field', (array) $args );

		$package_metabox = new WPML_Package_Translation_Metabox( $package, $wpdb, $sitepress, $args );
		$response        = array(
			'metabox' => $package_metabox->get_metabox_status(),
			'lang'    => $package_metabox->get_package_language_name(),
		);

		wp_send_json( $response );
	}

	private function get_editor_string_element( $string_name, $package_id, $column ) {
		global $wpdb;

		if ( 'title' === $column ) {
			return $wpdb->get_var(
				$wpdb->prepare(
					"SELECT title FROM {$wpdb->prefix}icl_strings WHERE string_package_id = %d AND name = %s",
					$package_id,
					$string_name
				)
			);
		}

		if ( 'type' === $column ) {
			return $wpdb->get_var(
				$wpdb->prepare(
					"SELECT type FROM {$wpdb->prefix}icl_strings WHERE string_package_id = %d AND name = %s",
					$package_id,
					$string_name
				)
			);
		}

		throw new InvalidArgumentException( 'Unsupported editor string column.' );
	}

	private function flush_cache() {
		wp_cache_delete( 'get_all_packages', $this->cache_group );
	}

	final public static function create_new_package( WPML_Package $package ) {
		$package_id = $package->create_new_package_record();

		if ( ! $package_id ) {
			return 0;
		}

		$tm = new WPML_Package_TM( $package );

		$tm->set_language_details();

		if ( ! $package->was_inserted() ) {
			return (int) $package_id;
		}

		do_action( 'wpml_st_package_created', $package );

		return (int) $package_id;
	}

	private function init_package_registered_strings( $package_id ) {
		if ( ! isset( $this->registered_strings[ $package_id ] ) ) {
			$this->registered_strings[ $package_id ] = array( 'strings' => array() );
		}
	}

	private function set_package_registered_strings( $package_id, $string_type, $string_title, $string_name, $string_value ) {
		$this->registered_strings[ $package_id ]['strings'][ $string_name ] = array(
			'title' => $string_title,
			'kind'  => $string_type,
			'value' => $string_value,
		);
	}

	private function get_string_id_from_package( $package, $string_name, $string_value ) {
		if ( ! $package instanceof WPML_Package ) {
			$package = $this->package_factory->create( $package );
		}

		return $package->get_string_id_from_package( $string_name, $string_value );
	}

	final function get_string_context( $package ) {
		return sanitize_title_with_dashes( $package['kind_slug'] . '-' . $package['name'] );
	}

	final function get_package_id( $package, $from_cache = true ) {
		global $wpdb;
		static $cache = array();

		if ( $this->is_a_package( $package ) ) {
			$package = object_to_array( $package );
		}

		$key = $this->get_string_context( $package );
		if ( ! $from_cache || ! array_key_exists( $key, $cache ) ) {
			$package_id = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->prefix}icl_string_packages WHERE kind_slug = %s AND name = %s",
					$package['kind_slug'],
					$package['name']
				)
			);
			if ( ! $package_id ) {
				return false;
			}
			$cache[ $key ] = $package_id;
		}

		return $cache[ $key ];
	}

	final public function get_all_packages() {
		global $wpdb;
		$cache_key   = 'get_all_packages';
		$cache_found = false;

		$all_packages = wp_cache_get( $cache_key, $this->cache_group, false, $cache_found );

		if ( ! $cache_found ) {
			$all_packages      = array();
			$all_packages_data = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}icl_string_packages" );
			foreach ( $all_packages_data as $package_data ) {
				$package                      = $this->package_factory->create_from_row( $package_data );
				$all_packages[ $package->ID ] = $package;
			}
			if ( $all_packages ) {
				wp_cache_set( $cache_key, $all_packages, $this->cache_group );
			}
		}

		return $all_packages;
	}

	final protected function is_a_package( $element ) {
		return is_a( $element, 'WPML_Package' );
	}

	protected function verify_ajax_call( $ajax_action ) {
		return isset( $_POST['wpnonce'] ) && wp_verify_nonce( $_POST['wpnonce'], $ajax_action );
	}

	protected function sanitize_string_name( $string_name ) {
		$string_name = preg_replace( '/[ \[\]]+/', '-', $string_name );

		return $string_name;
	}

	public function refresh_packages() {

		do_action( 'WPML_register_string_packages', 'layout', array() );

		do_action( 'wpml_register_string_packages' );
	}

	private function maybe_update_package( $package ) {
		if ( $package->new_title ) {
			$package->title = $package->new_title;
			$package->update_package_record();
		}
	}

	public function change_language_of_strings( $strings, $lang ) {
		global $wpdb;

		$all_ok = true;

		$package_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT string_package_id FROM {$wpdb->prefix}icl_strings WHERE id IN ("
				. implode( ', ', array_fill( 0, count( $strings ), '%d' ) ) . ')',
				$strings
			)
		);

		foreach ( $package_ids as $package_id ) {
			if ( $package_id ) {
				$package = $this->package_factory->create( $package_id );
				if ( ! $package->are_all_strings_included( $strings ) ) {
					$all_ok = false;
					break;
				}
			}
		}

		if ( $all_ok ) {
			$this->set_packages_language( $package_ids, $lang );
		}

		$response            = array();
		$response['success'] = $all_ok;
		if ( ! $all_ok ) {
			$response['error'] = __( 'Some of the strings selected belong to packages. You can only change the language of these strings if all strings in the packages are selected.', 'wpml-string-translation' );
		}

		return $response;
	}

	public function change_language_of_strings_in_domain( $domain, $langs, $to_lang ) {
		global $wpdb;

		if ( ! empty( $langs ) ) {
			$package_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT DISTINCT string_package_id FROM {$wpdb->prefix}icl_strings WHERE context = %s AND language IN ("
					. implode( ', ', array_fill( 0, count( $langs ), '%s' ) ) . ')',
					array_merge( array( $domain ), $langs )
				)
			);

			$this->set_packages_language( $package_ids, $to_lang );
		}

	}

	private function set_packages_language( $package_ids, $lang ) {
		foreach ( $package_ids as $package_id ) {
			if ( $package_id ) {
				$package = $this->package_factory->create( $package_id );
				$package->set_strings_language( $lang );

				$package_job = new WPML_Package_TM( $package );
				$package_job->set_language_details( $lang );
			}
		}
	}

	public function get_post_string_packages( $packages, $post_id ) {
		global $wpdb;

		$packages = $packages ? $packages : array();

		if ( ! \WPML\Upgrade\SchemaFacts::hasTable( 'icl_string_packages' ) ) {
			return $packages;
		}

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}icl_string_packages WHERE post_id = %d",
				$post_id
			)
		);

		foreach ( (array) $rows as $row ) {
			$packages[ $row->ID ] = $this->package_factory->create_from_row( $row );
		}

		return $packages;
	}

	public function add_string_translation_action( $string_id, $language, $value = null, $status = false, $translator_id = null, $translation_service = null, $batch_id = null ) {
		icl_add_string_translation( $string_id, $language, $value, $status, $translator_id, $translation_service, $batch_id );
	}

	public function get_string_package( $package, $package_data ) {
		return $this->package_factory->create( $package_data );
	}

	public function start_string_package_registration_action( $package ) {
		$this->package_cleanup->record_existing_strings( $this->package_factory->create( $package ) );
	}

	public function delete_unused_package_strings_action( $package ) {
		$this->package_cleanup->delete_unused_strings( $this->package_factory->create( $package ) );
	}
	
	public function get_active_string_package_kinds( $packages ) {
		$addons = [
			'WPML_PAGE_BUILDERS_VERSION'        => [
				'Block' => [
					'title'  => 'Widget',
					'plural' => 'Widgets',
					'slug'   => 'Block',
				],
			],
		];

		$isAddonEnabled = function( $value, $key ) {
			return defined( $key );
		};

		$automaticPackages = wpml_collect( $addons )
			->filter( $isAddonEnabled )
			->collapse()
			->all();

		if ( is_array( $packages ) ) {
			return array_merge( $packages, $automaticPackages );
		}

		return $automaticPackages;
	}

}
