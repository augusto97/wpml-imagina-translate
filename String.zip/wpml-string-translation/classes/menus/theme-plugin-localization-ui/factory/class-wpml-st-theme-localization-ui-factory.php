<?php

use function WPML\Container\make;

class WPML_ST_Theme_Localization_UI_Factory {

	const TEMPLATE_PATH = '/templates/theme-plugin-localization/';

	public function create(
		$localization = null,
		$utils = null,
		$repo = null
	) {
		global $wpdb;

		$localization = ( $localization ) ? $localization : new WPML_Localization( $wpdb );
		$utils        = ( $utils ) ? $utils : make( WPML_ST_Theme_Localization_Utils::class );
		$repo         = ( $repo ) ? $repo : make( \WPML\ST\TranslationFile\FilesToScanRepository::class );

		return new WPML_ST_Theme_Localization_UI( $localization, $utils, $repo, self::TEMPLATE_PATH );
	}
}
