/*jshint browser:true, devel:true */
/*global jQuery */
var WPML_core = WPML_core || {};

jQuery(function () {
    jQuery(document).on('change', '#icl_menu_language', WPML_core.wp_nav_language_change);

});

WPML_core.wp_nav_language_change = function() {
    var thiss = jQuery(this);
    thiss.attr('disabled', 'disabled');
    var trid = jQuery('#icl_nav_menu_trid').val();
    data = {icl_wp_nav_menu_ajax:'translation_of', lang:jQuery(this).val(), trid:trid};
    jQuery.ajax({
        type: 'POST',
        data: data,
        url: location.href,
        success: function(res){
            // wpmldev-5105: the response is raw markup from render_translation_of().
            // `wp_nav_menus` declares the `wpml-purify` dependency that defines this.
            jQuery('#icl_translation_of_wrap').html(WPML_core.purify(res));
            thiss.prop('disabled', false);
        }
    });
};

WPML_core.wp_nav_align_inputs = function() {

    WPML_core.wp_nav_fix_spacing_for_wp45();

    var inputs = ['#menu-name', '#icl_menu_language', '#icl_menu_translation_of'];

    var right_max = 0;
    var element;
    var position;
    for (var i = 0; i < 3; i++) {
        element = jQuery(inputs[i]);
        if (element.length) {
            position = jQuery(inputs[i]).offset().left;
            if (position > right_max) {
                right_max = position;
            }
        }
    }

    for ( i= 0; i < 3; i++) {
        element = jQuery(inputs[i]);
    }
};

WPML_core.wp_nav_fix_spacing_for_wp45 = function() {
    var wrapper = jQuery('#icl_menu_language').parent();
    if (wrapper.css('display') !== 'block') {
        wrapper.css({display: 'block'});
    }
};

jQuery(function () {
    jQuery('#wpml-ls-menu-management').appendTo('#menu-settings-column').show();
});
