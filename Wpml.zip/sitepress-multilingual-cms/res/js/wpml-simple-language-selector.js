var WPML_Core = WPML_Core || {};

WPML_Core.SimpleLanguageSelector = function () {
	var self         = this;

	var init = function () {
        jQuery(function () {
            self.initialize_select2();
        });
    };

    var escape_html = function ( value ) {
        return String( value )
            .replace( /&/g, '&amp;' )
            .replace( /"/g, '&quot;' )
            .replace( /</g, '&lt;' )
            .replace( />/g, '&gt;' );
    };

    var add_flags = function ( state ) {
        if (!state.id) { return escape_html( state.text ); }

        var text = escape_html( state.text );
        if (jQuery(state.element).data('status') == 'active' ) {
            text = '<strong>&nbsp;' + text + '</strong>';
        }

        return '<img width="18" height="12" src="' + escape_html( jQuery(state.element).data('flag_url') ) + '"/> ' + text;
    };

    self.initialize_select2 = function () {
        jQuery('.js-simple-lang-selector-flags').wpml_select2({
            formatResult:       add_flags,
            formatSelection:    add_flags,
            width:              'auto',
            dropdownCss:        {'z-index': parseInt(jQuery('.ui-dialog').css('z-index'), 10) + 100},
            dropdownAutoWidth:  true
        });

        var lang_selector_flags = jQuery('.js-simple-lang-selector-flags');

        if (lang_selector_flags.is(':disabled')) {
            lang_selector_flags.find('.wpml_select2-choice').addClass('button button-secondary').attr('disabled', 'true');
        }
	};

	init();

};

WPML_Core.simple_language_selector = new WPML_Core.SimpleLanguageSelector();
