<?php

use WPML\LIB\WP\User;

class WPML_TM_REST_Batch_Sync extends WPML_REST_Base {
	private $batch_sync_api;

	public function __construct( WPML_TP_Batch_Sync_API $batch_sync_api ) {
		parent::__construct( 'wpml/tm/v1' );
		$this->batch_sync_api = $batch_sync_api;
	}

	public function add_hooks() {
		$this->register_routes();
	}

	public function register_routes() {
		parent::register_route(
			'/tp/batches/sync',
			array(
				'methods'  => WP_REST_Server::CREATABLE,
				'callback' => array( $this, 'init' ),
				'args'     => array(
					'batchId' => array(
						'required'          => true,
						'validate_callback' => array( $this, 'validate_batch_ids' ),
						'sanitize_callback' => array( $this, 'sanitize_batch_ids' ),
					),
				),
			)
		);

		parent::register_route(
			'/tp/batches/status',
			array(
				'methods'  => WP_REST_Server::READABLE,
				'callback' => array( $this, 'check_progress' ),
			)
		);
	}

	public function init( WP_REST_Request $request ) {
		\WPML\TM\Jobs\JobLog::maybeInitRequest();
		\WPML\TM\Jobs\JobLog::createNewGroup(
			\WPML\TM\Jobs\JobLog::GROUP_ID_SYNC_JOBS,
			'TP batch sync init',
			array( 'batchIds' => $request->get_param( 'batchId' ) )
		);

		try {
			$queued = $this->batch_sync_api->init_synchronization( $request->get_param( 'batchId' ) );

			\WPML\TM\Jobs\JobLog::add( 'tp_batch_sync_queued', array( 'queued_batches' => $queued ) );
			\WPML\TM\Jobs\JobLog::finishCurrentGroup();

			return $queued;
		} catch ( Exception $e ) {
			\WPML\TM\Jobs\JobLog::addError( 'tp_batch_sync_init_failed', array( 'message' => $e->getMessage() ) );
			\WPML\TM\Jobs\JobLog::finishCurrentGroup();

			return \WPML\WordPress\ClientSafeError::wpError( 'TP batch sync init', $e );
		}
	}

	public function check_progress() {
		\WPML\TM\Jobs\JobLog::maybeInitRequest();
		\WPML\TM\Jobs\JobLog::createNewGroup(
			\WPML\TM\Jobs\JobLog::GROUP_ID_SYNC_JOBS,
			'TP batch sync status poll'
		);

		try {
			$queued = $this->batch_sync_api->check_progress();

			\WPML\TM\Jobs\JobLog::add( 'tp_batch_sync_still_queued', array( 'queued_batches' => $queued ) );
			\WPML\TM\Jobs\JobLog::finishCurrentGroup();

			return $queued;
		} catch ( Exception $e ) {
			\WPML\TM\Jobs\JobLog::addError( 'tp_batch_sync_status_failed', array( 'message' => $e->getMessage() ) );
			\WPML\TM\Jobs\JobLog::finishCurrentGroup();

			return \WPML\WordPress\ClientSafeError::wpError( 'TP batch sync progress', $e );
		}
	}


	public function get_allowed_capabilities( WP_REST_Request $request ) {
		return [ User::CAP_ADMINISTRATOR, User::CAP_MANAGE_TRANSLATIONS, User::CAP_TRANSLATE ];
	}

	public function validate_batch_ids( $batches ) {
		return is_array( $batches );
	}

	public function sanitize_batch_ids( $batches ) {
		return array_map( 'intval', $batches );
	}
}
