<?php

use \WPML\FP\Relation;
use \WPML\FP\Fns;
use WPML\TaxonomyTermTranslation\Hooks as TermTranslationHooks;

class WPML_Term_Query_Filter {

	const SLUG_MEMO_DROPPED_ON = [ 'created_term', 'edited_term', 'delete_term', 'clean_term_cache', 'wpml_translation_update' ];

	private $slug_memo;

	private $term_translation;

	private $debug_backtrace;

	private $wpdb;

	private $taxonomy_state;

	private $current_language;

	private $default_language;

	private $lock;

	private $opt_out;

	public function __construct(
		WPML_Term_Translation $term_translation,
		WPML_Debug_BackTrace $debug_backtrace,
		wpdb $wpdb,
		IWPML_Taxonomy_State $taxonomy_state,
		?WPML_Term_Query_Opt_Out $opt_out = null
	) {
		$this->term_translation = $term_translation;
		$this->debug_backtrace  = $debug_backtrace;
		$this->wpdb             = $wpdb;
		$this->taxonomy_state   = $taxonomy_state;
		$this->opt_out          = $opt_out ? $opt_out : new WPML_Term_Query_Opt_Out();
	}

	public function set_lang( $current_language, $default_language ) {
		$this->current_language = $current_language;
		$this->default_language = $default_language;
	}

	public function get_terms_args_filter( $args, $taxonomies ) {
		if ( $this->opt_out->is_id_adjustment_opted_out() ) {
			return $this->opt_out->is_stand_down_requested()
				? $args
				: $this->pin_slug_to_current_language( $args, $taxonomies );
		}

		if ( $this->lock ) {
			return $args;
		}

		if ( class_exists( 'WPML\TaxonomyTermTranslation\Hooks' ) && TermTranslationHooks::shouldSkip( $args ) ) {
			return $args;
		}

		if ( 0 === count( array_filter( (array) $taxonomies, array( $this->taxonomy_state, 'is_translated_taxonomy' ) ) ) ) {
			return $args;
		}

		$slug_memo_key = $this->slug_memo_key( $args, $taxonomies );
		if ( null !== $slug_memo_key ) {
			return $this->slug_memo()->remember(
				$slug_memo_key,
				function () use ( $args, $taxonomies ) {
					return $this->adjust_args( $args, $taxonomies );
				}
			);
		}

		return $this->adjust_args( $args, $taxonomies );
	}

	private function slug_memo() {
		if ( ! $this->slug_memo ) {
			$this->slug_memo = new \WPML\Utilities\RequestMemo( self::SLUG_MEMO_DROPPED_ON );
		}

		return $this->slug_memo;
	}

	private function slug_memo_key( $args, $taxonomies ) {
		if ( empty( $args['slug'] ) ) {
			return null;
		}

		try {
			return md5( serialize( [ $this->current_language, $this->default_language, is_admin(), (array) $taxonomies, $args ] ) );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	private function adjust_args( $args, $taxonomies ) {
		$this->lock = true;

		if ( isset( $args['cache_domain'] ) ) {
			$args['cache_domain'] .= '_' . $this->current_language;
		}

		$isOrderByEqualTo = Relation::propEq( 'orderby', Fns::__, $args );

		$params = array( 'include', 'exclude', 'exclude_tree' );
		foreach ( $params as $param ) {
			$adjusted_ids = $this->adjust_taxonomies_terms_ids( $args[ $param ], $isOrderByEqualTo( $param ) );

			if ( ! empty( $adjusted_ids ) ) {
				$args[ $param ] = $adjusted_ids;
			}
		}

		$params = array( 'child_of', 'parent' );
		foreach ( $params as $param ) {
			if ( ! isset( $args[ $param ] ) ) {
				continue;
			}

			$adjusted_ids = $this->adjust_taxonomies_terms_ids( $args[ $param ], $isOrderByEqualTo( $param ) );

			if ( ! empty( $adjusted_ids ) ) {
				$args[ $param ] = array_pop( $adjusted_ids );
			}
		}

		if ( ! empty( $args['slug'] ) ) {
			$args = $this->adjust_taxonomies_terms_slugs( $args, $taxonomies );
		}

		if ( $this->debug_backtrace->is_function_in_call_stack( '_get_term_hierarchy' ) ) {
			$args['_icl_show_all_langs'] = true;
		}

		$this->lock = false;
		return $args;
	}

	private function adjust_taxonomies_terms_ids( $terms_ids, $orderByTermId ) {
		$terms_ids = array_filter( array_unique( $this->explode_and_trim( $terms_ids ) ) );

		if ( empty( $terms_ids ) ) {
			return $terms_ids;
		}

		$terms          = $this->get_terms( $terms_ids, $orderByTermId );
		$translated_ids = array();

		$this->prefetch_translations( $terms );

		foreach ( $terms as $term ) {

			if ( $this->taxonomy_state->is_translated_taxonomy( $term->taxonomy ) ) {
				$translated_id = $this->term_translation->term_id_in( $term->term_id, $this->current_language );
				if ( ! $translated_id && ! is_admin() && $this->taxonomy_state->is_display_as_translated_taxonomy( $term->taxonomy ) ) {
					$translated_id = $this->term_translation->term_id_in( $term->term_id, $this->default_language );
				}
				$translated_ids[] = $translated_id;
			} else {
				$translated_ids[] = $term->term_id;
			}
		}

		return array_filter( $translated_ids );
	}

	private function prefetch_translations( $terms ) {
		$ttids = array();
		foreach ( $terms as $term ) {
			if ( ! empty( $term->term_taxonomy_id ) && $this->taxonomy_state->is_translated_taxonomy( $term->taxonomy ) ) {
				$ttids[] = (int) $term->term_taxonomy_id;
			}
		}

		if ( count( $ttids ) > 1 ) {
			$this->term_translation->prefetch_ids( $ttids );
		}
	}

	private function adjust_taxonomies_terms_slugs( $args, array $taxonomies ) {
		$terms_slugs = $args['slug'];
		if ( is_string( $terms_slugs ) ) {
			$terms_slugs = [ $terms_slugs ];
		}

		$duplicateSlugTranslations = [];
		$translated_slugs          = [];
		$translated_term           = null;
		foreach ( $terms_slugs as $terms_slug ) {
			$term = $this->guess_term( $terms_slug, $taxonomies );

			if ( $term ) {
				$translated_id   = $this->term_translation->term_id_in( $term->term_id, $this->current_language );
				$translated_term = get_term( $translated_id, $term->taxonomy );
				if ( $translated_term instanceof WP_Term ) {
					if ( $terms_slug === $translated_term->slug ) {
						$duplicateSlugTranslations[] = $translated_id;
					}
					$terms_slug = $translated_term->slug;
				}
			}
			$translated_slugs[] = $terms_slug;
		}

		if ( is_admin() && count( $duplicateSlugTranslations ) === 1 ) {
			$args['include'] = $duplicateSlugTranslations;
			$args['slug']    = '';
		} else {
			$args['slug'] = array_filter( $translated_slugs );

			if (
				! is_admin()
				&& 1 === count( $terms_slugs )
				&& $translated_term instanceof WP_Term
				&& empty( $args['term_taxonomy_id'] )
				&& count( $this->term_translation->term_ids_by_slug( $translated_term->slug, $translated_term->taxonomy ) ) > 1
			) {
				$args['term_taxonomy_id'] = [ (int) $translated_term->term_taxonomy_id ];
			}
		}

		return $args;
	}

	private function pin_slug_to_current_language( $args, $taxonomies ) {
		$taxonomies = (array) $taxonomies;
		$slugs      = empty( $args['slug'] ) ? [] : (array) $args['slug'];

		if (
			$this->lock
			|| 1 !== count( $slugs )
			|| 1 !== count( $taxonomies )
			|| ! empty( $args['term_taxonomy_id'] )
			|| ! $this->current_language
			|| 'all' === $this->current_language
			|| ( class_exists( 'WPML\TaxonomyTermTranslation\Hooks' ) && TermTranslationHooks::shouldSkip( $args ) )
		) {
			return $args;
		}

		$slug     = (string) reset( $slugs );
		$taxonomy = (string) reset( $taxonomies );
		if (
			! $this->taxonomy_state->is_translated_taxonomy( $taxonomy )
			|| count( $this->term_translation->term_ids_by_slug( $slug, $taxonomy ) ) < 2
		) {
			return $args;
		}

		$term = $this->term_in_current_language( $slug, $taxonomy );
		if ( $term ) {
			$args['term_taxonomy_id'] = [ (int) $term->term_taxonomy_id ];
		}

		return $args;
	}

	private function get_terms( $ids, $orderByTermId ) {
		if ( ! $ids ) {
			return array();
		}

		$wpdb = $this->wpdb;
		$ids  = array_map( 'intval', $ids );
		if ( $orderByTermId ) {
			return $wpdb->get_results(
				$wpdb->prepare(
					"SELECT taxonomy, term_id, term_taxonomy_id FROM {$wpdb->term_taxonomy}
					WHERE term_id IN (" . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ')
					ORDER BY FIELD(term_id, ' . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ')',
					array_merge( $ids, $ids )
				)
			);
		}

		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT taxonomy, term_id, term_taxonomy_id FROM {$wpdb->term_taxonomy}
				WHERE term_id IN (" . implode( ', ', array_fill( 0, count( $ids ), '%d' ) ) . ')',
				$ids
			)
		);
	}

	private function guess_term( $slug, array $taxonomies ) {
		foreach ( $taxonomies as $taxonomy ) {
			$term = $this->term_in_current_language( $slug, $taxonomy );

			if ( ! $term ) {
				$term = get_term_by( 'slug', $slug, $taxonomy );
			}

			if ( $term ) {
				return $term;
			}
		}

		return null;
	}

	private function term_in_current_language( $slug, $taxonomy ) {
		foreach ( $this->term_translation->term_ids_by_slug( $slug, $taxonomy ) as $term_id ) {
			if ( $this->term_translation->lang_code_by_termid( $term_id ) === $this->current_language ) {
				$term = get_term( $term_id, $taxonomy );

				return $term instanceof WP_Term ? $term : null;
			}
		}

		return null;
	}

	private function explode_and_trim( $source ) {
		if ( ! is_array( $source ) ) {
			$source = array_map( 'trim', explode( ',', $source ) );
		}

		return $source;
	}

}
