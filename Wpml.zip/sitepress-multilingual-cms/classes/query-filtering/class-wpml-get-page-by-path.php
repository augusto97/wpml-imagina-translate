<?php

class WPML_Get_Page_By_Path {

	const BEFORE_REMOVE_PLACEHOLDER_ESCAPE_PRIORITY = -1;

	private $wpdb;

	private $sitepress;

	private $debug_backtrace;

	private $language;

	private $post_type;

	public function __construct( wpdb $wpdb, SitePress $sitepress, WPML_Debug_BackTrace $debug_backtrace ) {
		$this->wpdb            = $wpdb;
		$this->sitepress       = $sitepress;
		$this->debug_backtrace = $debug_backtrace;
	}

	public function get( $page_name, $lang, $output = OBJECT, $post_type = 'page' ) {
		$this->post_type = $post_type;
		$this->language  = $lang;

		$post_types = array( $post_type );

		$this->clear_cache( $page_name, $post_types );

		add_filter( 'query', [ $this, 'get_page_by_path_filter' ], self::BEFORE_REMOVE_PLACEHOLDER_ESCAPE_PRIORITY );
		$temp_lang_switch = new WPML_Temporary_Switch_Language( $this->sitepress, $lang );
		$page             = get_page_by_path( $page_name, $output, $post_types );
		$temp_lang_switch->restore_lang();
		remove_filter( 'query', [ $this, 'get_page_by_path_filter' ], self::BEFORE_REMOVE_PLACEHOLDER_ESCAPE_PRIORITY );

		return $page;
	}

	public function get_page_by_path_filter( $query ) {
		if (
			$this->sitepress->is_translated_post_type( $this->post_type )
			&& $this->debug_backtrace->is_function_in_call_stack( 'get_page_by_path' )
		) {

			$wpdb  = $this->wpdb;
			$where = $wpdb->prepare(
				"ID IN ( SELECT element_id FROM {$wpdb->prefix}icl_translations WHERE language_code = %s AND element_type LIKE %s ) AND ",
				$this->language,
				'post_%'
			);

			$query = str_replace( 'WHERE ', 'WHERE ' . $where, $query );
		}

		return $query;
	}

	private function clear_cache( $page_name, $post_types ) {
		$hash = md5( $page_name . serialize( $post_types ) );
		$last_changed             = wp_cache_get_last_changed( 'posts' );
		$cache_key_with_timestamp = "get_page_by_path:$hash:$last_changed";
		wp_cache_delete( $cache_key_with_timestamp, 'posts' );
		wp_cache_delete( $cache_key_with_timestamp, 'post-queries' );
		$cache_key = "get_page_by_path:$hash";
		wp_cache_delete( $cache_key, 'posts' );
		wp_cache_delete( $cache_key, 'post-queries' );
	}
}
