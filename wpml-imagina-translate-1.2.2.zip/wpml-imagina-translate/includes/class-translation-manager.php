<?php
/**
 * Translation Manager - Orchestrates the translation process
 */

if (!defined('ABSPATH')) {
    exit;
}

class WIT_Translation_Manager {

    private $wpml_integration;
    private $content_parser;
    private $settings;

    public function __construct() {
        $this->wpml_integration = WIT_WPML_Integration::instance();
        $this->content_parser = new WIT_Content_Parser();
        $this->settings = WIT_Settings::instance()->get_settings();
    }

    /**
     * Translate a single post
     *
     * @param int $post_id
     * @param string $target_language
     * @return array {success: bool, message: string, translated_post_id: int}
     */
    public function translate_post($post_id, $target_language) {
        $post = get_post($post_id);

        if (!$post) {
            return array(
                'success' => false,
                'message' => __('Post no encontrado', 'wpml-imagina-translate'),
                'translated_post_id' => 0,
            );
        }

        $source_language = $this->wpml_integration->get_post_language($post_id);
        $elementor       = new WIT_Elementor_Handler();
        $is_elementor    = $elementor->is_elementor_post($post_id);

        try {
            // Title and excerpt in one request. Each used to be its own round
            // trip, and with a real model every round trip is a second or two.
            $fields = array();
            if (trim((string) $post->post_title) !== '') {
                $fields['title'] = $post->post_title;
            }
            if (trim((string) $post->post_excerpt) !== '') {
                $fields['excerpt'] = $post->post_excerpt;
            }

            $batched = array();
            if (!empty($fields)) {
                $engine  = new WIT_Translator_Engine();
                $results = $engine->translate_batch(array_values($fields), $target_language, $source_language);
                $batched = array_combine(array_keys($fields), $results);
            }

            if (isset($batched['title']) && !empty($batched['title']['error'])) {
                throw new Exception($batched['title']['error']);
            }

            $title_result = array(
                'title' => isset($batched['title']) ? $batched['title']['translation'] : $post->post_title,
            );

            $excerpt = '';
            if (isset($batched['excerpt']) && empty($batched['excerpt']['error'])) {
                $excerpt = $batched['excerpt']['translation'];
            }

            // Translate content.
            // For Elementor posts the editable content lives in _elementor_data
            // (post meta), not in post_content.  Elementor's front-end renderer
            // ignores post_content entirely, so there is no point translating it —
            // we just preserve it as-is and handle the Elementor data separately
            // after the translated post has been created/updated.
            if ($is_elementor) {
                $content_result = array(
                    'content' => '',  // Elementor will regenerate this from _elementor_data
                    'error'   => null,
                    'debug'   => array('Elementor post detected — content will be translated from _elementor_data'),
                );
            } else {
                $content_result = $this->content_parser->translate_content(
                    $post->post_content,
                    $target_language,
                    $source_language
                );
            }

            // Debug info is now provided directly by the parser
            $debug_info = isset($content_result['debug']) ? $content_result['debug'] : array();

            if ($content_result['error']) {
                throw new Exception($content_result['error']);
            }

            $translated_data = array(
                'title'   => $title_result['title'],
                'content' => $content_result['content'],
                'excerpt' => $excerpt,
            );

            // Check if translation already exists
            $existing_translation_id = $this->wpml_integration->get_translation_id($post_id, $target_language);

            if ($existing_translation_id) {
                // Update existing translation
                $success = $this->wpml_integration->update_translated_post($existing_translation_id, $translated_data, $post_id);

                if (is_wp_error($success)) {
                    throw new Exception($success->get_error_message());
                }

                if ($success) {
                    // Translate Elementor data if applicable
                    if ($is_elementor) {
                        $el_result  = $elementor->translate($post_id, $existing_translation_id, $target_language, $source_language);
                        $debug_info = array_merge($debug_info, $el_result['debug']);

                        if (!empty($el_result['error'])) {
                            throw new Exception($el_result['error']);
                        }
                    }

                    // Translate meta fields if enabled
                    if ($this->settings['translate_meta_fields']) {
                        $this->translate_meta_fields($post_id, $existing_translation_id, $target_language, $source_language);
                    }

                    $this->log_translation($post_id, $target_language, 'success', 'Updated existing translation');

                    return array(
                        'success'            => true,
                        'message'            => __('Traducción actualizada exitosamente', 'wpml-imagina-translate'),
                        'translated_post_id' => $existing_translation_id,
                        'debug'              => $debug_info,
                    );
                } else {
                    throw new Exception(__('Error al actualizar la traducción', 'wpml-imagina-translate'));
                }
            } else {
                // Create new translation
                $new_post_id = $this->wpml_integration->create_translated_post($post_id, $target_language, $translated_data);

                if (is_wp_error($new_post_id)) {
                    throw new Exception($new_post_id->get_error_message());
                }

                // Translate Elementor data if applicable
                if ($is_elementor) {
                    $el_result  = $elementor->translate($post_id, $new_post_id, $target_language, $source_language);
                    $debug_info = array_merge($debug_info, $el_result['debug']);

                    if (!empty($el_result['error'])) {
                        throw new Exception($el_result['error']);
                    }
                }

                // Translate meta fields if enabled
                if ($this->settings['translate_meta_fields']) {
                    $this->translate_meta_fields($post_id, $new_post_id, $target_language, $source_language);
                }

                $this->log_translation($post_id, $target_language, 'success', 'Created new translation');

                return array(
                    'success'            => true,
                    'message'            => __('Traducción creada exitosamente', 'wpml-imagina-translate'),
                    'translated_post_id' => $new_post_id,
                    'debug'              => $debug_info,
                );
            }
        } catch (\Throwable $e) {
            $message = $e->getMessage() ?: __('Error interno durante la traducción', 'wpml-imagina-translate');
            $this->log_translation($post_id, $target_language, 'error', $message);

            return array(
                'success'            => false,
                'message'            => $message,
                'translated_post_id' => 0,
            );
        }
    }

    /**
     * Translate meta fields
     *
     * @param int $source_post_id
     * @param int $target_post_id
     * @param string $target_language
     * @param string $source_language
     */
    private function translate_meta_fields($source_post_id, $target_post_id, $target_language, $source_language) {
        $meta_fields = array_filter(array_map('trim', explode(',', $this->settings['meta_fields_list'])));

        if (empty($meta_fields)) {
            return;
        }

        // Collect first, then translate in one batched call. The previous
        // implementation issued a separate API request per meta field.
        $values = array();

        foreach ($meta_fields as $meta_key) {
            // Elementor's own meta is handled by WIT_Elementor_Handler; letting
            // it through here would send serialized page data to the API.
            if (strpos($meta_key, '_elementor') === 0) {
                continue;
            }

            $value = get_post_meta($source_post_id, $meta_key, true);

            if (!is_string($value) || trim($value) === '') {
                continue;
            }

            $values[$meta_key] = $value;
        }

        if (empty($values)) {
            return;
        }

        $keys         = array_keys($values);
        $translator   = new WIT_Translator_Engine();
        $translations = $translator->translate_batch(array_values($values), $target_language, $source_language);

        foreach ($keys as $index => $meta_key) {
            if (isset($translations[$index])
                && empty($translations[$index]['error'])
                && $translations[$index]['translation'] !== '') {
                update_post_meta($target_post_id, $meta_key, wp_slash($translations[$index]['translation']));
            }
        }
    }

    /**
     * Log translation
     *
     * @param int $post_id
     * @param string $target_language
     * @param string $status
     * @param string $message
     */
    private function log_translation($post_id, $target_language, $status, $message = '') {
        global $wpdb;

        $source_language = $this->wpml_integration->get_post_language($post_id);
        $ai_provider = $this->settings['ai_provider'];

        $wpdb->insert(
            $wpdb->prefix . 'wit_translation_logs',
            array(
                'post_id' => $post_id,
                'source_lang' => $source_language,
                'target_lang' => $target_language,
                'ai_provider' => $ai_provider,
                'status' => $status,
                'message' => $message,
                'created_at' => current_time('mysql'),
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s', '%s')
        );
    }

    /**
     * Get translation logs
     *
     * @param int $limit
     * @return array
     */
    public function get_translation_logs($limit = 50) {
        global $wpdb;

        $logs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}wit_translation_logs ORDER BY created_at DESC LIMIT %d",
                $limit
            ),
            ARRAY_A
        );

        // Add post title to each log
        foreach ($logs as &$log) {
            $post = get_post($log['post_id']);
            $log['post_title'] = $post ? $post->post_title : __('Post eliminado', 'wpml-imagina-translate');
        }

        return $logs;
    }

    /**
     * Get translation statistics
     *
     * @return array
     */
    public function get_statistics() {
        global $wpdb;

        $stats = array();

        // Total translations
        $stats['total'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}wit_translation_logs"
        );

        // Successful translations
        $stats['successful'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}wit_translation_logs WHERE status = 'success'"
        );

        // Failed translations
        $stats['failed'] = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->prefix}wit_translation_logs WHERE status = 'error'"
        );

        // Translations by provider
        $stats['by_provider'] = $wpdb->get_results(
            "SELECT ai_provider, COUNT(*) as count FROM {$wpdb->prefix}wit_translation_logs GROUP BY ai_provider",
            ARRAY_A
        );

        // Recent activity (last 7 days)
        $stats['recent'] = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}wit_translation_logs WHERE created_at >= %s",
                date('Y-m-d H:i:s', strtotime('-7 days'))
            )
        );

        return $stats;
    }
}
